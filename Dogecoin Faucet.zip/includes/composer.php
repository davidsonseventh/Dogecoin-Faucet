{
  "require": {
    "php": "5.5.12",
    "ext-gmp": "*"
  }
}